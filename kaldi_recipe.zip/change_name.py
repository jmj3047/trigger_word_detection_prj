import glob
import subprocess
file_names = glob.glob("/data/recordings/*.wav")


for f in file_names:
    name = f.split("/")[-1].split(".")[0]
    seg = name.split("_")
    com = "mv {} /data/recordings/{}_{}_{}.wav".format(f, seg[1], seg[0], seg[2])
    subprocess.check_output(com, shell=True)
    