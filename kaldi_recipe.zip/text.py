import subprocess

# create *_path.scp
com1 = 'find /opt/kaldi/egs/digits/digits_audio/train/ -iname *.wav > train_path.scp'
com2 = 'find /opt/kaldi/egs/digits/digits_audio/test/ -iname *.wav > test_path.scp'
subprocess.call(com1, shell=True)
subprocess.call(com2, shell=True)

# create *.ID.scp
com_a = "cat train_path.scp | awk -F / '{print($9)}' | awk -F . '{print($1)}' > train_ID.scp"
com_b = "cat test_path.scp | awk -F / '{print($9)}' | awk -F . '{print($1)}' > test_ID.scp"
subprocess.call(com_a, shell=True)
subprocess.call(com_b, shell=True)

# spk2gender
with open("/opt/kaldi/egs/digits/data/test/spk2gender", 'wt') as te:
    te.write("theo m\n")

with open("/opt/kaldi/egs/digits/data/train/spk2gender", 'wt') as tr:
    tr.write("jackson m\n")
    tr.write("nicolas m\n")
    tr.write("yweweler m\n")
    

# wav.scp
com5 = 'paste -d " " train_ID.scp train_path.scp > /opt/kaldi/egs/digits/data/train/wav.scp' 
com6 = 'paste -d " " test_ID.scp test_path.scp > /opt/kaldi/egs/digits/data/test/wav.scp' 
subprocess.call(com5, shell=True)
subprocess.call(com6, shell=True)



test_ID = open("./test_ID.scp", "rt")
train_ID = open("./train_ID.scp", "rt")

# text
with open("/opt/kaldi/egs/digits/data/test/text", "wt") as textF:
    while True:
        l1 = test_ID.readline()
        if not l1:
            break
        textID = l1.split("_")[1]
        if textID == "0":
            textF.write(l1[:-1]+" zero\n")
        elif textID == "1":
            textF.write(l1[:-1]+" one\n")
        elif textID == "2":
            textF.write(l1[:-1]+" two\n")
        elif textID == "3":
            textF.write(l1[:-1]+" three\n")
        elif textID == "4":
            textF.write(l1[:-1]+" four\n")  
        elif textID == "5":
            textF.write(l1[:-1]+" five\n")
        elif textID == "6":
            textF.write(l1[:-1]+" six\n")
        elif textID == "7":
            textF.write(l1[:-1]+" seven\n")
        elif textID == "8":
            textF.write(l1[:-1]+" eight\n")
        elif textID == "9":
            textF.write(l1[:-1]+" nine\n")

with open("/opt/kaldi/egs/digits/data/train/text", "wt") as textF:
    while True:
        l1 = train_ID.readline()
        if not l1:
            break
        textID = l1.split("_")[1]
        if textID == "0":
            textF.write(l1[:-1]+" zero\n")
        elif textID == "1":
            textF.write(l1[:-1]+" one\n")
        elif textID == "2":
            textF.write(l1[:-1]+" two\n")
        elif textID == "3":
            textF.write(l1[:-1]+" three\n")
        elif textID == "4":
            textF.write(l1[:-1]+" four\n")  
        elif textID == "5":
            textF.write(l1[:-1]+" five\n")
        elif textID == "6":
            textF.write(l1[:-1]+" six\n")
        elif textID == "7":
            textF.write(l1[:-1]+" seven\n")
        elif textID == "8":
            textF.write(l1[:-1]+" eight\n")
        elif textID == "9":
            textF.write(l1[:-1]+" nine\n")

test_ID = open("./test_ID.scp", "rt")
train_ID = open("./train_ID.scp", "rt")

# utt2spk
with open("/opt/kaldi/egs/digits/data/test/utt2spk", 'w') as ifp:
    l1 = test_ID.readlines()
    for lines in l1:
        ifp.write(lines[:-1] + " theo\n")
    

with open("/opt/kaldi/egs/digits/data/train/utt2spk", 'w') as ifp:
    l1 = train_ID.readlines()

    for lines in l1:
        if "nicolas" in lines:
            ifp.write(lines[:-1] + " nicolas\n")
        elif "jackson" in lines:
            ifp.write(lines[:-1] + " jackson\n")
        elif "yweweler" in lines:
            ifp.write(lines[:-1] + " yweweler\n")
            

# corpus.txt
com = "mkdir /opt/kaldi/egs/digits/data/local"
#subprocess.call(com, shell=True)
a = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine']
with open("/opt/kaldi/egs/digits/data/local/corpus.txt", 'w') as ifp:
    for i in a:
        ifp.write(i + '\n')


